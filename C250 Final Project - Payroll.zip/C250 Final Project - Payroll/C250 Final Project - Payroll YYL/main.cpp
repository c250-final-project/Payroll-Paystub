//
//  main.cpp
//  C250 Final Project - Payroll YYL
//
//  Created by Yan Yan Ley on 4/2/19.
//  Copyright © 2019 Yan Yan Ley. All rights reserved.
//

#include <iostream>
#include "Paystub.hpp"

using namespace std;

int main(int argc, const char * argv[]) {
    
    PayrollMainMenu();

    return 0;
}
