//
//  NewEmployee.hpp
//  PayrollProgram
//
//  Created by Justin Adriano on 4/4/19.
//  Copyright © 2019 Justin Adriano. All rights reserved.
//

#ifndef NewEmployee_hpp
#define NewEmployee_hpp

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

#endif /* NewEmployee_hpp */
using namespace std;

class NEW_EMPLOYEE {

private :
    string firstName;
    string lastName;
    string employee_name;
    int employee_id;
    int ID_number;
    
    string employee_address;
   // double employee_phone_number;
    string employee_hire_date,hireDate;
    string employee_designation;
    int employee_PayGrade;
    int employee_loan;
//    int employee_salary;
//    int employee_housing_allowance;

public:
    NEW_EMPLOYEE();
    
    NEW_EMPLOYEE( int ,string , string, string, string, int, int, string );
    
//    NEW_EMPLOYEE (int ID_Number);
//    
//    NEW_EMPLOYEE (string employee_address);
//    
    
    
    void set_employee_name (string fname, string lname);
    
    void set_employee_id (int ID_Number);
    void set_employee_address (string address);
    void set_employee_hire_date (string hireDate);
    void set_employee_PayGrade (int employeegrade);
    void set_employee_loan (int employeeloan);
    void set_employee_designation (string designation);
    
    
    string get_employee_name()const;
    int get_employee_id()const;
    string get_employee_address()const;
    
    string get_employee_hire_date()const;
    int get_employee_PayGrade()const;
    int get_employee_loan ()const;
    string get_employee_designation()const;
    
    
    
    
    
    
    
};
    

