//
//  NewEmployee.cpp
//  PayrollProgram
//
//  Created by Justin Adriano on 4/4/19.
//  Copyright © 2019 Justin Adriano. All rights reserved.
//

#include "NewEmployee.hpp"
#include <vector>

using namespace std;

NEW_EMPLOYEE::NEW_EMPLOYEE(int ID_number,string fname, string lname,string address,string hireDate, int PayGrade, int loan,
                           string designation) {
    employee_id = ID_number;
    firstName = fname;
    lastName = lname;
    employee_address = address;
    employee_hire_date = hireDate;
    employee_PayGrade = PayGrade;
    employee_loan = loan;
    employee_designation = designation;
    
}

//NEW_EMPLOYEE::NEW_EMPLOYEE(int ID_number) {
//    employee_id = ID_number;
//}
//
//NEW_EMPLOYEE::NEW_EMPLOYEE (string address) {
//    employee_address = address;
//}
//
//NEW_EMPLOYEE::NEW_EMPLOYEE(){
//    employee_hire_date = hireDate;
//}


void NEW_EMPLOYEE::set_employee_name (string fname, string lname){
    employee_name = fname + " " + lname;
}
string NEW_EMPLOYEE::get_employee_name() const {
    return firstName + " " +lastName;
}
void NEW_EMPLOYEE::set_employee_id (int ID_number){
    employee_id = ID_number;
}
int NEW_EMPLOYEE::get_employee_id () const{
    return employee_id;
}

void NEW_EMPLOYEE::set_employee_address(string address) {
    employee_address = address;
    
}

string NEW_EMPLOYEE::get_employee_address() const {
    return employee_address;
}
void NEW_EMPLOYEE::set_employee_hire_date(string hireDate){
    employee_hire_date =  hireDate ;
}
string NEW_EMPLOYEE::get_employee_hire_date()const{
    return employee_hire_date;
}


void NEW_EMPLOYEE::set_employee_PayGrade (int PayGrade) {
    employee_PayGrade = PayGrade;
}
int NEW_EMPLOYEE::get_employee_PayGrade () const{
    return employee_PayGrade;
}
void NEW_EMPLOYEE::set_employee_loan (int loan) {
    employee_loan = loan;
}
int NEW_EMPLOYEE::get_employee_loan () const{
    return employee_loan;
}
void NEW_EMPLOYEE::set_employee_designation (string designation){
    employee_designation = designation;
}

string NEW_EMPLOYEE::get_employee_designation () const {
    return employee_designation;
}
