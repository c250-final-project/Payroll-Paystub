//
//  Paystub.hpp
//  C250 Final Project - Payroll YYL
//
//  Created by Yan Yan Ley on 4/2/19.
//  Copyright © 2019 Yan Yan Ley. All rights reserved.
//

#ifndef Paystub_hpp
#define Paystub_hpp

#include <stdio.h>
#include <iostream>
#include <iomanip>

using namespace std;

class PAYROLL{
private:
    string EmployeeFullName;
    string EmployeeID;
    string Address;
    float PayRate;
    string PayStartDate;
    string PayEndDate;
    float HoursWorked;
    float OverTimeHoursWorked;
    float VacationHoursUsed;
    float GrossPay;
    float FederalTax;
    float StateTax;
    float NetPay;
    
public:
    PAYROLL();
    PAYROLL(string a, string b, string c, float d, string e, string f, float g, float h, float i){
        
        EmployeeFullName = a;
        EmployeeID = b;
        Address = c;
        PayRate = d;
        PayStartDate = e;
        PayEndDate = f;
        HoursWorked = g;
        OverTimeHoursWorked = h;
        VacationHoursUsed = i;
    }
    //PAYROLL class setters
    string set_EmployeeFullName();
    string set_EmployeeID();
    string set_Address();
    float set_PayRate();
    string set_PayStartDate();
    string set_PayEndDate();
    float set_HoursWorked();
    float set_OverTimeHoursWorked();
    float set_VacationHoursUsed();
    
    //PAYROLL class getters
    string get_EmployeeFullName();
    string get_EmployeeID();
    string get_Address();
    float get_PayRate();
    string get_PayStartDate();
    string get_PayEndDate();
    float get_HoursWorked();
    float get_OverTimeHoursWorked();
    float get_VacationHoursUsed();
    float get_GrossPay();
    float get_FederalTax();
    float get_StateTax();
    float get_NetPay();
    
    //PAYROLL methods
    float GrossPayCalc(float PayRate, float HoursWorked, float VacationHoursUsed, float OverTimeHoursWorked);
    float FederalTaxCalc(float PayRate, float HoursWorked, float VacationHoursUsed, float OverTimeHoursWorked);
    float StateTaxCalc(float PayRate, float HoursWorked, float VacationHoursUsed, float OverTimeHoursWorked);
    float NetPayCalc(float GrossPay, float FederalTax, float StateTax);
};

//Menu, search and display methods
void PayrollMainMenu ();
void SearchByEmployeeName();
void SearchByEmployeeID();
void ReturnToMainMenu();
void DisplayPayroll(PAYROLL a);
void PrintPaystub(PAYROLL a);

#endif /* Paystub_hpp */
